# Vim ColorScheme

Clone the repo somewhere.

```sh
git clone https://github.com/folke/tokyonight.nvim ~/projects/tokyonight.nvim
```

Add the below to your `~/.vimrc` file.

```vim
set termguicolors
set rtp+=~/projects/tokyonight.nvim/extras/vim
colorscheme tokyonight
```
